<?php

echo "Hola pelades del stream";

?>
