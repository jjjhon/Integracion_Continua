# Reglas de buena conducta:
- No preguntes si puedes preguntar, __simplemente preguntá__.
- Usa __hilos__ para responder, y por favor no marques que se copie en el canal. La idea es que en el canal se vean solo las preguntas o temas principales y en los hilos las respuestas o reacciones.
- Por favor __comparte los logs y errores__ que estás viendo. Si tu log o captura es muy grande, por favor usa un hilo para postearlo.
- Da feedback si ha funcionado la solución aportada. 
